# 📂 법률 데이터 벡터 DB 조회 시스템

이 프로젝트는 FAISS 기반의 벡터 데이터베이스와 메타데이터를 활용하여,  
간단한 자연어 질문에 대해 관련 문서를 검색/조회할 수 있는 테스트용 시스템입니다.

---

## 📁 폴더 구조
├── vector_db/
│ ├── faiss.index # 벡터 인덱스 파일
│ └── metadata.json # 문서 메타데이터 (ID, 제목, 종류 등)
│ └── inspect_vector_db.py # 벡터 DB 상태를 확인하고 메타데이터를 점검하는 도구
├── api/
│ └── search_api.py # FastAPI 기반 검색 API
├── client/
│ └── test_query.py # CLI 기반 테스트 도구
├── requirements.txt # 의존성 패키지 목록
└── README.md # 설명서

---

## 🚀 실행 순서

### 1. 가상환경 활성화 (선택)
```bash
python -m venv .venv
source .venv/Scripts/activate  # (Windows 기준)
pip install -r requirements.txt
```


### 2. 검색 API 서버 실행
``` bash
uvicorn api.search_api:app --reload
```
### 3. CLI 테스트 실행
```bash
python client/test_query.py # 새 터미널에서 실행
```

