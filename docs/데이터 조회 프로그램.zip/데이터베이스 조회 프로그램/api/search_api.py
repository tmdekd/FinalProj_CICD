from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import faiss
import numpy as np
import pickle
from sentence_transformers import SentenceTransformer

model = SentenceTransformer('all-MiniLM-L6-v2')
index = faiss.read_index("vector_db/faiss.index")
with open("vector_db/metadata.pkl", "rb") as f:
    docs = pickle.load(f)

app = FastAPI()

class QueryInput(BaseModel):
    question: str
    type: str = None

@app.post("/search")
def search(query: QueryInput):
    if not query.question.strip():
        raise HTTPException(status_code=400, detail="질문이 비어 있습니다.")

    vec = model.encode(query.question).reshape(1, -1).astype("float32")
    D, I = index.search(vec, k=3)

    results = []
    for i in I[0]:
        if i >= len(docs):
            continue
        doc = docs[i]
        if query.type and doc.get("type") != query.type:
            continue
        results.append({
            "id": doc["id"],
            "type": doc.get("type"),
            "metadata": doc["metadata"],
            "content_snippet": doc["content"][:200]
        })
    return {"results": results}
