import requests

question = input("질문을 입력하세요: ")
type_filter = input("문서 타입을 입력하세요 (예: 판례, 문서) 또는 Enter: ").strip()
payload = {"question": question}
if type_filter:
    payload["type"] = type_filter

res = requests.post("http://localhost:8000/search", json=payload)
print("검색 결과:")
print(res.json())
