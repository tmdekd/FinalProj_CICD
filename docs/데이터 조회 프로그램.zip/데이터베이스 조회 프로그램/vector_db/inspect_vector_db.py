# vector_db/inspect_vector_db.py

import faiss
import os
import json

index_path = "vector_db/faiss.index"
meta_path = "vector_db/metadata.json"

# FAISS 인덱스 확인
if not os.path.exists(index_path):
    print("❌ 벡터 인덱스 파일이 없습니다.")
    exit()

index = faiss.read_index(index_path)
print("✅ FAISS 인덱스 로드 완료")

print(f"🧠 벡터 개수: {index.ntotal}")
print(f"🧭 벡터 차원: {index.d}")

# 메타데이터 확인
if os.path.exists(meta_path):
    with open(meta_path, encoding="utf-8") as f:
        metadata = json.load(f)
    print(f"📝 메타데이터 개수: {len(metadata)}")
    print("📋 예시:")
    for i, item in enumerate(metadata[:3]):
        print(f"  [{i+1}] ID: {item['id']} / Type: {item.get('type')} / 파일명: {item.get('filename', '-')}")
else:
    print("⚠️ metadata.json이 존재하지 않습니다.")
print("✅ 벡터 DB 검사 완료")